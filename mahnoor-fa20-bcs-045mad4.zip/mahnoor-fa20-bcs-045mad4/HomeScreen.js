import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

export default function HomeScreen() {
  const [person, setPerson] = useState(null);

  const handleProfilePress = () => {
    const personData = {
      name: 'Mahnoor',
      
      Email: 'm@gmail.com',
      location: 'pakistan',
    };
    setPerson(personData);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to My App</Text>
      {person ? (
        <View style={styles.personContainer}>
          <Text style={styles.label}>Name:</Text>
          <Text style={styles.value}>{person.name}</Text>
          
          <Text style={styles.label}>Email:</Text>
          <Text style={styles.value}>{person.Email}</Text>
          <Text style={styles.label}>Location:</Text>
          <Text style={styles.value}>{person.location}</Text>
        </View>
      ) : (
        <TouchableOpacity onPress={handleProfilePress} style={styles.button}>
          <Text style={styles.buttonText}>Go to Profile</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'purple',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  button: {
    backgroundColor: 'black',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginTop: 20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  personContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 5,
  },
  value: {
    fontSize: 16,
  },
});
